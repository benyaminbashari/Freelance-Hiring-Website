package com.mexfc.restapi.service.request;

public class ReqBody {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}